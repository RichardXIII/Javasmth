import br.com.fiap.banco.model.Cliente;

public class Main {
    public static void main(String[] args){
        /* Instanciar um cliente */
        Cliente cliente = new Cliente();
        //Colocar um nome e senha para o cliente
        cliente.setUsername("robert");
        cliente.setSenha("hahaha123");

        System.out.println("Username: " + cliente.getUsername());
        System.out.println("Senha: " + cliente.getSenha());

        //Chamar o metodo para logar
        boolean loga = cliente.logar("robert", "hahaha123");
        System.out.println("Logou?: " + loga);

    }


}